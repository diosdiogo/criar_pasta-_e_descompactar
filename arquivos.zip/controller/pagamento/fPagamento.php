<?php

    include_once 'resources/views/Formas_de_Pagamento.html';

    include 'resources/footer.php';
    ?>
    <script>
    <?php 
    include_once 'controller/pagamento/fPagamento.js';
    include_once 'controller/app/funcoesBasicas.js';
    ?>

</script>

</body>
</html>