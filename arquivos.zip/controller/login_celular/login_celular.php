<?php  

    include_once 'resources/views/login_celular.html';

    include_once 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/login_celular/login_celular.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>