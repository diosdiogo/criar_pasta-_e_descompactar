<?php  

    include_once 'resources/views/C_digo_de_verifica__o.html';

    include_once 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/codigo/codigoNumero.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>