<?php  

    include_once 'resources/views/Telefone.html';

    include_once 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/verifica/verifica.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>