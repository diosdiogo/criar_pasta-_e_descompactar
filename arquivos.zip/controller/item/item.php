<?php  
    include_once 'resources/views/item.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/item/item.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>