<?php  
    include_once 'resources/views/Endereco_entrega.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/endereco/listaEndereco_entrega.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>