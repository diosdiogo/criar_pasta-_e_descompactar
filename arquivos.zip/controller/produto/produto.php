<?php

    include_once 'resources/views/produto.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/produto/produto.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>