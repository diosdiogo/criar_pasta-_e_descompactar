<?php  
    include_once 'resources/views/Perfil.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/perfil/perfil.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>