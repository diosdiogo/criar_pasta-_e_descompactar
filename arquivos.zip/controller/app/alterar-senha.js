$scope.esqueceuSenha = function(){
    //$("#Login").modal("hide");
    //$("#trocarsenha").modal("show");
}