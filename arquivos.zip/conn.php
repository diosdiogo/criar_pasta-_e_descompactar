<?php  

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');

$conexao = mysqli_connect('db-brasilmobile.caungtcgcwfr.sa-east-1.rds.amazonaws.com', 'root', 'lxmcz2016', 'zmpro');
