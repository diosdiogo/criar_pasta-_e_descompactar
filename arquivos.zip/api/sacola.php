<?php
    date_default_timezone_set('America/Bahia');
    $array = json_decode(file_get_contents("php://input"), true);
